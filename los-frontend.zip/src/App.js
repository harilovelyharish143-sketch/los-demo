
import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const login = async () => {
    try {
      const res = await axios.post(
        process.env.REACT_APP_API_URL + '/api/auth/login',
        { username, password }
      );
      setMessage(res.data);
    } catch (e) {
      setMessage('Error connecting to backend');
    }
  };

  return (
    <div style={{ padding: 40 }}>
      <h2>LOS Login</h2>
      <input placeholder="Username" onChange={e => setUsername(e.target.value)} /><br/><br/>
      <input type="password" placeholder="Password" onChange={e => setPassword(e.target.value)} /><br/><br/>
      <button onClick={login}>Login</button>
      <p>{message}</p>
    </div>
  );
}

export default App;
